-- ===========================================
-- CREATE TABLE: category
-- ===========================================
CREATE TABLE category (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT
);

-- ===========================================
-- CREATE TABLE: product
-- ===========================================
CREATE TABLE product (
    id SERIAL PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    price NUMERIC(10,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (category_id) REFERENCES category(id)
);

-- ===========================================
-- CREATE TABLE: location
-- ===========================================
CREATE TABLE location (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    address TEXT
);

-- ===========================================
-- CREATE TABLE: stock_movements
-- ===========================================
CREATE TABLE stock_movements (
    id SERIAL PRIMARY KEY,
    product_id INT NOT NULL,
    location_id INT NOT NULL,
    movement_type VARCHAR(20) NOT NULL CHECK (movement_type IN ('IN', 'OUT')),
    quantity INT NOT NULL CHECK (quantity > 0),
    movement_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (product_id) REFERENCES product(id),
    FOREIGN KEY (location_id) REFERENCES location(id)
);

-----------------------------------------------------
-- CATEGORY (10)
-----------------------------------------------------
INSERT INTO category (name, description) VALUES
('Herramientas manuales', 'Herramientas utilizadas manualmente'),
('Herramientas eléctricas', 'Herramientas que requieren electricidad'),
('Materiales de construcción', 'Materiales utilizados en obras'),
('Pinturas y recubrimientos', 'Pinturas, esmaltes y similares'),
('Plomería', 'Accesorios y materiales para plomería'),
('Electricidad', 'Material eléctrico de instalación'),
('Jardinería', 'Herramientas y accesorios de jardín'),
('Tornillería', 'Tornillos, tuercas, pernos y fijaciones'),
('Seguridad industrial', 'Equipos de seguridad personal'),
('Adhesivos y selladores', 'Pegamentos y selladores');

-----------------------------------------------------
-- PRODUCT (10) - ID de categoría entre 1 y 10
-----------------------------------------------------
INSERT INTO product (category_id, name, description, price) VALUES
(1, 'Martillo de carpintero', 'Martillo con mango de madera reforzado', 150.00),
(1, 'Destornillador plano', 'Destornillador de acero inoxidable', 45.00),
(2, 'Taladro eléctrico', 'Taladro de 600W con velocidad variable', 950.00),
(2, 'Esmeriladora angular', 'Esmeriladora de 4.5 pulgadas', 780.00),
(3, 'Cemento gris 50kg', 'Saco de cemento gris para construcción', 210.00),
(4, 'Pintura blanca 19L', 'Pintura vinílica para interiores', 650.00),
(5, 'Llave stilson', 'Llave ajustable de 14 pulgadas', 230.00),
(8, 'Tornillos para madera 1"', 'Caja con 100 tornillos', 60.00),
(9, 'Guantes de carnaza', 'Guantes de seguridad industrial', 90.00),
(10, 'Silicón transparente', 'Silicón multiusos de alta resistencia', 55.00);

-----------------------------------------------------
-- LOCATION (10)
-----------------------------------------------------
INSERT INTO location (name, address) VALUES
('Almacén Central', 'Avenida Industrial 100'),
('Sucursal Norte', 'Calle Laureles 55'),
('Sucursal Sur', 'Boulevard del Sol 220'),
('Sucursal Este', 'Calle Cedros 17'),
('Sucursal Oeste', 'Calzada del Bosque 88'),
('Bodega Auxiliar A', 'Camino a la Montaña km 3'),
('Bodega Auxiliar B', 'Carretera Vieja 45'),
('Punto de Entrega 1', 'Plaza Central Local 12'),
('Punto de Entrega 2', 'Plaza del Parque Local 5'),
('Centro de Distribución', 'Anillo Periférico 300');

-----------------------------------------------------
-- STOCK_MOVEMENTS (10)
-- movement_type: 'IN' o 'OUT'
-----------------------------------------------------
INSERT INTO stock_movements (product_id, location_id, movement_type, quantity, notes) VALUES
(1, 1, 'IN', 30, 'Ingreso de proveedor'),
(2, 1, 'IN', 50, 'Ingreso de proveedor'),
(3, 2, 'IN', 15, 'Ingreso inicial'),
(4, 2, 'OUT', 5, 'Venta mostrador'),
(5, 3, 'IN', 60, 'Compra para obra'),
(6, 4, 'OUT', 3, 'Salida por devolución'),
(7, 5, 'IN', 25, 'Reposición de inventario'),
(8, 6, 'OUT', 10, 'Venta a cliente mayorista'),
(9, 7, 'IN', 40, 'Equipo de seguridad recibido'),
(10, 1, 'OUT', 8, 'Venta mostrador');
